import React, { useState, useEffect, useRef, useCallback, useMemo } from "react";
import {
  Search, Mic, Camera as CameraIcon, MessageSquare, History as HistoryIcon,
  Settings as SettingsIcon, Home as HomeIcon, ArrowLeftRight, Copy, Share2,
  Volume2, X, Star, Trash2, ChevronRight, Check, Sparkles,
  Loader2, ArrowLeft, ShieldCheck, Info, SlidersHorizontal, Users, ScanLine,
  RotateCcw, Zap, BookOpen, ChevronDown,
} from "lucide-react";

/* ============================================================================
   ZED AI — Smart Translator
   ----------------------------------------------------------------------------
   ARCHITECTURE NOTE — READ BEFORE SHIPPING
   ----------------------------------------------------------------------------
   This file is the presentation + client state layer only. Text-to-speech
   uses the browser's real SpeechSynthesis API (genuine, not mocked). Speech
   input uses the browser's real SpeechRecognition API when the browser
   supports it, and falls back to a labeled demo transcript when it doesn't.

   Translation itself (text, voice, camera OCR, conversation) runs through
   `translateWithAI()` below, which is currently wired to DEMO_MODE = true.
   No AI translation API key is available in this environment, so ZED AI
   never fabricates full AI output — it returns a small set of verified
   sample translations plus a clearly labeled demo notice for anything else.

   TO CONNECT A REAL AI BACKEND:
   1. Stand up a small backend route, e.g. POST /api/translate
      body: { text, sourceLang, targetLang, style }
      That route calls your AI/translation provider server-side (Anthropic
      Claude, Google Cloud Translation, DeepL, Azure Translator, etc.) using
      an API key read from a server environment variable — NEVER shipped to
      the client.
   2. Replace the body of `translateWithAI()` below with a fetch() to that
      route, and set DEMO_MODE = false.
   3. Do the same for OCR (POST /api/ocr, e.g. Google Vision or Tesseract on
      the server) inside `runOcrOnCapture()`.
   ========================================================================== */

const DEMO_MODE = true;

/* ---------------------------------- Theme --------------------------------- */

const C = {
  bg: "#0A0A0B",
  bgSoft: "#0E0F10",
  surface: "#141416",
  surface2: "#1B1C1E",
  surface3: "#222325",
  border: "#26262A",
  borderSoft: "#1E1F21",
  neon: "#39FF9C",
  neonSoft: "#2BD98A",
  neonDim: "rgba(57,255,156,0.12)",
  neonBorder: "rgba(57,255,156,0.35)",
  neonGlow: "rgba(57,255,156,0.28)",
  text: "#F4F5F3",
  textDim: "#9A9AA1",
  textFaint: "#5A5A61",
  danger: "#FF6B6B",
};

const FontLoader = () => (
  <style>{`
    @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=Inter:wght@400;500;600;700&display=swap');
    .zed-root, .zed-root * { box-sizing: border-box; font-family: 'Inter', sans-serif; }
    .zed-display { font-family: 'Space Grotesk', sans-serif; }
    .zed-root { -webkit-tap-highlight-color: transparent; }
    .zed-scroll::-webkit-scrollbar { width: 0px; height: 0px; }
    .zed-fade-in { animation: zedFadeIn .28s ease both; }
    @keyframes zedFadeIn { from { opacity:0; transform: translateY(6px);} to {opacity:1; transform:translateY(0);} }
    @keyframes zedPulse { 0%,100% { opacity:1; } 50% { opacity:.4; } }
    @keyframes zedScan { 0% { top: 6%; } 50% { top: 90%; } 100% { top: 6%; } }
    @keyframes zedSpin { to { transform: rotate(360deg); } }
    @keyframes zedGlowPulse { 0%,100% { box-shadow: 0 0 0 0 rgba(57,255,156,0.35);} 50% { box-shadow: 0 0 0 10px rgba(57,255,156,0);} }
    .zed-focus:focus-visible { outline: 2px solid ${C.neon}; outline-offset: 2px; }
    textarea.zed-focus:focus, input.zed-focus:focus { outline: none; }
  `}</style>
);

/* -------------------------------- Languages -------------------------------- */

const LANGUAGES = [
  { code: "auto", name: "Detect language", native: "Auto", flag: "✨" },
  { code: "en", name: "English", native: "English", flag: "🇬🇧" },
  { code: "uz", name: "Uzbek", native: "Oʻzbekcha", flag: "🇺🇿" },
  { code: "ru", name: "Russian", native: "Русский", flag: "🇷🇺" },
  { code: "tr", name: "Turkish", native: "Türkçe", flag: "🇹🇷" },
  { code: "ar", name: "Arabic", native: "العربية", flag: "🇸🇦" },
  { code: "zh", name: "Chinese", native: "中文", flag: "🇨🇳" },
  { code: "ko", name: "Korean", native: "한국어", flag: "🇰🇷" },
  { code: "ja", name: "Japanese", native: "日本語", flag: "🇯🇵" },
  { code: "de", name: "German", native: "Deutsch", flag: "🇩🇪" },
  { code: "fr", name: "French", native: "Français", flag: "🇫🇷" },
  { code: "es", name: "Spanish", native: "Español", flag: "🇪🇸" },
  { code: "it", name: "Italian", native: "Italiano", flag: "🇮🇹" },
  { code: "pt", name: "Portuguese", native: "Português", flag: "🇵🇹" },
  { code: "hi", name: "Hindi", native: "हिन्दी", flag: "🇮🇳" },
];

const BCP47 = { en: "en-US", uz: "uz-UZ", ru: "ru-RU", tr: "tr-TR", ar: "ar-SA", zh: "zh-CN", ko: "ko-KR", ja: "ja-JP", de: "de-DE", fr: "fr-FR", es: "es-ES", it: "it-IT", pt: "pt-PT", hi: "hi-IN" };

const langByCode = (code) => LANGUAGES.find((l) => l.code === code) || LANGUAGES[1];

const STYLES = [
  { id: "standard", label: "Standard" },
  { id: "formal", label: "Formal" },
  { id: "casual", label: "Casual" },
  { id: "professional", label: "Professional" },
];

/* ------------------------- Demo phrase dictionary --------------------------
   A small, verified set of translations used only to demonstrate real output
   in the UI while DEMO_MODE is true. Everything outside this set returns a
   clearly labeled placeholder instead of a fabricated translation.
------------------------------------------------------------------------- */

const PHRASES = {
  "hello": { uz: "Salom", ru: "Привет", tr: "Merhaba", ar: "مرحبا", zh: "你好", ko: "안녕하세요", ja: "こんにちは", de: "Hallo", fr: "Bonjour", es: "Hola", it: "Ciao", pt: "Olá", hi: "नमस्ते", en: "Hello" },
  "thank you": { uz: "Rahmat", ru: "Спасибо", tr: "Teşekkür ederim", ar: "شكرا لك", zh: "谢谢", ko: "감사합니다", ja: "ありがとう", de: "Danke schön", fr: "Merci", es: "Gracias", it: "Grazie", pt: "Obrigado", hi: "धन्यवाद", en: "Thank you" },
  "how are you": { uz: "Qalaysiz", ru: "Как дела", tr: "Nasılsın", ar: "كيف حالك", zh: "你好吗", ko: "어떻게 지내세요", ja: "お元気ですか", de: "Wie geht es dir", fr: "Comment ça va", es: "¿Cómo estás?", it: "Come stai", pt: "Como você está", hi: "आप कैसे हैं", en: "How are you" },
  "good morning": { uz: "Xayrli tong", ru: "Доброе утро", tr: "Günaydın", ar: "صباح الخير", zh: "早上好", ko: "좋은 아침이에요", ja: "おはようございます", de: "Guten Morgen", fr: "Bonjour", es: "Buenos días", it: "Buongiorno", pt: "Bom dia", hi: "सुप्रभात", en: "Good morning" },
  "good night": { uz: "Xayrli tun", ru: "Спокойной ночи", tr: "İyi geceler", ar: "تصبح على خير", zh: "晚安", ko: "안녕히 주무세요", ja: "おやすみなさい", de: "Gute Nacht", fr: "Bonne nuit", es: "Buenas noches", it: "Buonanotte", pt: "Boa noite", hi: "शुभ रात्रि", en: "Good night" },
  "i love you": { uz: "Men seni sevaman", ru: "Я тебя люблю", tr: "Seni seviyorum", ar: "أحبك", zh: "我爱你", ko: "사랑해요", ja: "愛しています", de: "Ich liebe dich", fr: "Je t'aime", es: "Te quiero", it: "Ti amo", pt: "Eu te amo", hi: "मैं तुमसे प्यार करता हूँ", en: "I love you" },
  "where is the bathroom": { uz: "Hojatxona qayerda", ru: "Где туалет", tr: "Tuvalet nerede", ar: "أين الحمام", zh: "洗手间在哪里", ko: "화장실이 어디예요", ja: "お手洗いはどこですか", de: "Wo ist die Toilette", fr: "Où sont les toilettes", es: "¿Dónde está el baño?", it: "Dov'è il bagno", pt: "Onde fica o banheiro", hi: "बाथरूम कहाँ है", en: "Where is the bathroom" },
  "what is your name": { uz: "Ismingiz nima", ru: "Как тебя зовут", tr: "Adın ne", ar: "ما اسمك", zh: "你叫什么名字", ko: "이름이 뭐예요", ja: "お名前は何ですか", de: "Wie heißt du", fr: "Comment tu t'appelles", es: "¿Cómo te llamas?", it: "Come ti chiami", pt: "Qual é o seu nome", hi: "आपका नाम क्या है", en: "What is your name" },
  "how much does this cost": { uz: "Bu qancha turadi", ru: "Сколько это стоит", tr: "Bu ne kadar", ar: "كم يكلف هذا", zh: "这个多少钱", ko: "이거 얼마예요", ja: "これはいくらですか", de: "Wie viel kostet das", fr: "Combien ça coûte", es: "¿Cuánto cuesta esto?", it: "Quanto costa questo", pt: "Quanto custa isso", hi: "इसकी कीमत कितनी है", en: "How much does this cost" },
  "welcome": { uz: "Xush kelibsiz", ru: "Добро пожаловать", tr: "Hoş geldiniz", ar: "أهلا بك", zh: "欢迎", ko: "환영합니다", ja: "ようこそ", de: "Willkommen", fr: "Bienvenue", es: "Bienvenido", it: "Benvenuto", pt: "Bem-vindo", hi: "स्वागत है", en: "Welcome" },
  "i am sorry": { uz: "Kechirasiz", ru: "Мне жаль", tr: "Özür dilerim", ar: "أنا آسف", zh: "对不起", ko: "죄송합니다", ja: "すみません", de: "Es tut mir leid", fr: "Je suis désolé", es: "Lo siento", it: "Mi dispiace", pt: "Sinto muito", hi: "मुझे खेद है", en: "I am sorry" },
  "see you later": { uz: "Ko'rishguncha", ru: "Увидимся позже", tr: "Sonra görüşürüz", ar: "أراك لاحقا", zh: "回头见", ko: "나중에 봐요", ja: "また後で", de: "Bis später", fr: "À plus tard", es: "Hasta luego", it: "A dopo", pt: "Até logo", hi: "फिर मिलेंगे", en: "See you later" },
};

const STYLE_SUFFIX = {
  formal: { en: "", note: "formal register" },
  casual: { en: "", note: "casual register" },
  professional: { en: "", note: "professional register" },
  standard: { en: "", note: "" },
};

/* ------------------------------ AI translation ------------------------------ */

function translateWithAI({ text, sourceLang, targetLang, style }) {
  const clean = text.trim();
  const key = clean.toLowerCase().replace(/[.!?¡¿]+$/g, "");
  const target = targetLang === "auto" ? "en" : targetLang;

  return new Promise((resolve) => {
    const delay = 650 + Math.random() * 550;
    setTimeout(() => {
      if (PHRASES[key] && PHRASES[key][target]) {
        resolve({ text: PHRASES[key][target], demo: false, detected: "en" });
      } else {
        resolve({
          text: clean,
          demo: true,
          detected: sourceLang === "auto" ? "en" : sourceLang,
        });
      }
    }, delay);
  });
}

function runOcrOnCapture() {
  const samples = [
    "Welcome to the city center. Please keep your ticket for the return journey.",
    "Opening hours: Monday to Saturday, 9 AM to 8 PM.",
    "Thank you for visiting. Please do not touch the artwork.",
  ];
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(samples[Math.floor(Math.random() * samples.length)]);
    }, 1100);
  });
}

/* -------------------------------- Storage ----------------------------------- */

async function storageGet(key, fallback) {
  try {
    const res = await window.storage.get(key, false);
    if (!res) return fallback;
    return JSON.parse(res.value);
  } catch (e) {
    return fallback;
  }
}
async function storageSet(key, value) {
  try {
    await window.storage.set(key, JSON.stringify(value), false);
  } catch (e) {
    /* best effort — app still works in-memory this session */
  }
}

function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

/* --------------------------------------------------------------------------
   Shared UI primitives
-------------------------------------------------------------------------- */

const IconBtn = ({ icon: Icon, onClick, active, size = 18, label, danger }) => (
  <button
    onClick={onClick}
    aria-label={label}
    title={label}
    className="zed-focus"
    style={{
      display: "flex", alignItems: "center", justifyContent: "center",
      width: 38, height: 38, borderRadius: 12,
      background: active ? C.neonDim : C.surface2,
      border: `1px solid ${active ? C.neonBorder : C.borderSoft}`,
      color: danger ? C.danger : active ? C.neon : C.textDim,
      cursor: "pointer", transition: "all .15s ease", flexShrink: 0,
    }}
  >
    <Icon size={size} strokeWidth={2} />
  </button>
);

const Card = ({ children, style, ...rest }) => (
  <div
    {...rest}
    style={{
      background: C.surface,
      border: `1px solid ${C.borderSoft}`,
      borderRadius: 20,
      padding: 16,
      ...style,
    }}
  >
    {children}
  </div>
);

const GlowButton = ({ children, onClick, disabled, loading, icon: Icon, style }) => (
  <button
    onClick={onClick}
    disabled={disabled || loading}
    className="zed-focus"
    style={{
      width: "100%", display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
      padding: "15px 18px", borderRadius: 16, border: "none",
      background: disabled ? C.surface3 : C.neon,
      color: disabled ? C.textFaint : "#06120C",
      fontWeight: 600, fontSize: 15.5, cursor: disabled ? "default" : "pointer",
      boxShadow: disabled ? "none" : `0 8px 24px -6px ${C.neonGlow}`,
      transition: "transform .12s ease, box-shadow .2s ease",
      ...style,
    }}
    onMouseDown={(e) => { if (!disabled) e.currentTarget.style.transform = "scale(0.98)"; }}
    onMouseUp={(e) => { e.currentTarget.style.transform = "scale(1)"; }}
  >
    {loading ? (
      <Loader2 size={19} style={{ animation: "zedSpin .8s linear infinite" }} />
    ) : Icon ? (
      <Icon size={19} />
    ) : null}
    {children}
  </button>
);

const Pill = ({ active, children, onClick }) => (
  <button
    onClick={onClick}
    className="zed-focus"
    style={{
      padding: "8px 15px", borderRadius: 999, whiteSpace: "nowrap",
      background: active ? C.neonDim : "transparent",
      border: `1px solid ${active ? C.neonBorder : C.borderSoft}`,
      color: active ? C.neon : C.textDim,
      fontSize: 13.5, fontWeight: 500, cursor: "pointer", transition: "all .15s ease",
    }}
  >
    {children}
  </button>
);

const DemoBadge = ({ compact }) => (
  <span
    style={{
      display: "inline-flex", alignItems: "center", gap: 5,
      padding: compact ? "3px 8px" : "4px 10px", borderRadius: 999,
      background: "rgba(255,255,255,0.06)", border: `1px solid ${C.borderSoft}`,
      color: C.textDim, fontSize: 11, fontWeight: 600, letterSpacing: 0.2,
    }}
  >
    <Zap size={11} color={C.neon} /> Demo mode
  </span>
);

const ScreenHeader = ({ title, subtitle, onBack, right }) => (
  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "18px 20px 8px" }}>
    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
      {onBack && (
        <button onClick={onBack} className="zed-focus" style={{ background: "none", border: "none", color: C.text, cursor: "pointer", display: "flex", padding: 4, marginLeft: -6 }} aria-label="Back">
          <ArrowLeft size={20} />
        </button>
      )}
      <div>
        <div className="zed-display" style={{ fontSize: 21, fontWeight: 600, color: C.text }}>{title}</div>
        {subtitle && <div style={{ fontSize: 13, color: C.textDim, marginTop: 2 }}>{subtitle}</div>}
      </div>
    </div>
    {right}
  </div>
);

const EmptyState = ({ icon: Icon, title, sub }) => (
  <div style={{ textAlign: "center", padding: "48px 24px", color: C.textDim }}>
    <div style={{ width: 56, height: 56, borderRadius: 16, background: C.surface2, border: `1px solid ${C.borderSoft}`, display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 14px" }}>
      <Icon size={24} color={C.textFaint} />
    </div>
    <div style={{ color: C.text, fontWeight: 600, fontSize: 15, marginBottom: 4 }}>{title}</div>
    <div style={{ fontSize: 13, lineHeight: 1.5 }}>{sub}</div>
  </div>
);

/* --------------------------------------------------------------------------
   Language picker sheet
-------------------------------------------------------------------------- */

const LanguageSheet = ({ open, onClose, onPick, current, excludeAuto }) => {
  const [q, setQ] = useState("");
  useEffect(() => { if (open) setQ(""); }, [open]);
  if (!open) return null;
  const list = LANGUAGES.filter((l) => !(excludeAuto && l.code === "auto"));
  const filtered = list.filter(
    (l) => l.name.toLowerCase().includes(q.toLowerCase()) || l.native.toLowerCase().includes(q.toLowerCase())
  );
  return (
    <div
      style={{ position: "absolute", inset: 0, zIndex: 50, display: "flex", alignItems: "flex-end" }}
      onClick={onClose}
    >
      <div style={{ position: "absolute", inset: 0, background: "rgba(0,0,0,0.55)" }} />
      <div
        onClick={(e) => e.stopPropagation()}
        className="zed-fade-in"
        style={{
          position: "relative", width: "100%", maxHeight: "78%", background: C.bgSoft,
          borderTopLeftRadius: 24, borderTopRightRadius: 24, border: `1px solid ${C.borderSoft}`,
          borderBottom: "none", display: "flex", flexDirection: "column", overflow: "hidden",
        }}
      >
        <div style={{ width: 36, height: 4, borderRadius: 4, background: C.surface3, margin: "10px auto 4px" }} />
        <div style={{ padding: "10px 18px 12px" }}>
          <div className="zed-display" style={{ fontSize: 17, fontWeight: 600, color: C.text, marginBottom: 10 }}>Choose a language</div>
          <div style={{ display: "flex", alignItems: "center", gap: 8, background: C.surface2, border: `1px solid ${C.borderSoft}`, borderRadius: 13, padding: "9px 12px" }}>
            <Search size={16} color={C.textFaint} />
            <input
              autoFocus
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search languages"
              className="zed-focus"
              style={{ background: "none", border: "none", color: C.text, fontSize: 14.5, width: "100%" }}
            />
          </div>
        </div>
        <div className="zed-scroll" style={{ overflowY: "auto", padding: "0 10px 18px" }}>
          {filtered.map((l) => (
            <button
              key={l.code}
              onClick={() => { onPick(l.code); onClose(); }}
              className="zed-focus"
              style={{
                width: "100%", display: "flex", alignItems: "center", justifyContent: "space-between",
                padding: "12px 10px", borderRadius: 14, background: current === l.code ? C.neonDim : "transparent",
                border: "none", cursor: "pointer", textAlign: "left",
              }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <span style={{ fontSize: 20 }}>{l.flag}</span>
                <div>
                  <div style={{ color: C.text, fontSize: 14.5, fontWeight: 500 }}>{l.name}</div>
                  <div style={{ color: C.textFaint, fontSize: 12 }}>{l.native}</div>
                </div>
              </div>
              {current === l.code && <Check size={17} color={C.neon} />}
            </button>
          ))}
          {filtered.length === 0 && (
            <div style={{ textAlign: "center", color: C.textFaint, padding: "30px 0", fontSize: 13.5 }}>No languages match "{q}"</div>
          )}
        </div>
      </div>
    </div>
  );
};

const LangChip = ({ code, onClick }) => {
  const l = langByCode(code);
  return (
    <button
      onClick={onClick}
      className="zed-focus"
      style={{
        display: "flex", alignItems: "center", gap: 7, padding: "9px 13px", borderRadius: 13,
        background: C.surface2, border: `1px solid ${C.borderSoft}`, color: C.text,
        fontSize: 14, fontWeight: 500, cursor: "pointer", flex: 1, justifyContent: "center",
      }}
    >
      <span style={{ fontSize: 15 }}>{l.flag}</span>
      <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{l.name}</span>
      <ChevronDown size={14} color={C.textFaint} style={{ flexShrink: 0 }} />
    </button>
  );
};

/* --------------------------------------------------------------------------
   Speech helpers — TTS is real (SpeechSynthesis). STT uses SpeechRecognition
   when the browser exposes it, otherwise falls back to a labeled demo
   transcript so the flow still works end to end.
-------------------------------------------------------------------------- */

function speak(text, langCode, rate = 1) {
  try {
    if (!window.speechSynthesis || !text) return;
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = BCP47[langCode] || "en-US";
    u.rate = rate;
    window.speechSynthesis.speak(u);
  } catch (e) { /* no-op */ }
}

function getRecognition() {
  const Rec = window.SpeechRecognition || window.webkitSpeechRecognition;
  return Rec ? new Rec() : null;
}

const DEMO_TRANSCRIPTS = [
  "Hello, how are you today",
  "Thank you very much for your help",
  "Where is the nearest train station",
  "I would like to book a table for two",
];

function useVoiceInput(langCode) {
  const [listening, setListening] = useState(false);
  const [demo, setDemo] = useState(false);
  const recRef = useRef(null);

  const start = useCallback((onResult) => {
    const rec = getRecognition();
    if (rec) {
      try {
        rec.lang = BCP47[langCode] || "en-US";
        rec.interimResults = false;
        rec.maxAlternatives = 1;
        rec.onresult = (e) => {
          const transcript = e.results?.[0]?.[0]?.transcript || "";
          onResult(transcript, false);
        };
        rec.onerror = () => setListening(false);
        rec.onend = () => setListening(false);
        recRef.current = rec;
        setDemo(false);
        setListening(true);
        rec.start();
        return;
      } catch (e) { /* fall through to demo */ }
    }
    // Demo fallback — no live speech recognition available in this environment
    setDemo(true);
    setListening(true);
    setTimeout(() => {
      setListening(false);
      const t = DEMO_TRANSCRIPTS[Math.floor(Math.random() * DEMO_TRANSCRIPTS.length)];
      onResult(t, true);
    }, 1400);
  }, [langCode]);

  const stop = useCallback(() => {
    try { recRef.current && recRef.current.stop(); } catch (e) {}
    setListening(false);
  }, []);

  return { listening, demo, start, stop };
}

/* --------------------------------------------------------------------------
   Loading / scan animation used while a translation request is in flight
-------------------------------------------------------------------------- */

const ScanLoader = ({ label = "Translating" }) => (
  <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "14px 4px" }}>
    <div style={{ position: "relative", width: 22, height: 22, borderRadius: 7, overflow: "hidden", background: C.surface3, flexShrink: 0 }}>
      <div style={{ position: "absolute", left: 0, right: 0, height: 2, background: C.neon, boxShadow: `0 0 8px 1px ${C.neonGlow}`, animation: "zedScan 1.1s ease-in-out infinite" }} />
    </div>
    <span style={{ color: C.textDim, fontSize: 13.5 }}>{label}…</span>
  </div>
);

const MicPulse = ({ size = 64 }) => (
  <div style={{ position: "relative", width: size, height: size, display: "flex", alignItems: "center", justifyContent: "center" }}>
    <div style={{ position: "absolute", inset: 0, borderRadius: "50%", border: `2px solid ${C.neon}`, animation: "zedGlowPulse 1.4s ease-out infinite" }} />
    <div style={{ width: size * 0.62, height: size * 0.62, borderRadius: "50%", background: C.neon, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: `0 0 22px 2px ${C.neonGlow}` }}>
      <Mic size={size * 0.32} color="#06120C" />
    </div>
  </div>
);

/* --------------------------------------------------------------------------
   Result card — shared by Translate / Camera / Voice outputs
-------------------------------------------------------------------------- */

const ResultCard = ({ sourceText, result, targetLang, isFavorite, onToggleFavorite, ttsRate }) => {
  const [copied, setCopied] = useState(false);
  if (!result) return null;
  const tgt = langByCode(targetLang);

  const copy = async () => {
    try { await navigator.clipboard.writeText(result.text); setCopied(true); setTimeout(() => setCopied(false), 1500); } catch (e) {}
  };
  const share = async () => {
    try {
      if (navigator.share) await navigator.share({ text: result.text });
      else copy();
    } catch (e) {}
  };

  return (
    <Card style={{ borderColor: C.neonBorder, background: `linear-gradient(180deg, ${C.neonDim}, ${C.surface})` }} className="zed-fade-in">
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 7, color: C.textDim, fontSize: 12.5, fontWeight: 500 }}>
          <span>{tgt.flag}</span><span>{tgt.name}</span>
        </div>
        {result.demo && <DemoBadge compact />}
      </div>
      <div style={{ color: C.text, fontSize: 18, lineHeight: 1.5, fontWeight: 500, marginBottom: result.demo ? 8 : 14 }}>
        {result.text}
      </div>
      {result.demo && (
        <div style={{ color: C.textFaint, fontSize: 12.5, lineHeight: 1.5, marginBottom: 14, paddingTop: 8, borderTop: `1px solid ${C.borderSoft}` }}>
          Live AI translation isn't connected in this environment, so ZED AI is showing your original text instead of a guessed result. Try “hello”, “thank you”, or “good morning” to see a verified sample translation — see Settings → About ZED AI for how to connect a real API.
        </div>
      )}
      <div style={{ display: "flex", gap: 8 }}>
        <IconBtn icon={copied ? Check : Copy} label="Copy translation" onClick={copy} active={copied} />
        <IconBtn icon={Share2} label="Share translation" onClick={share} />
        <IconBtn icon={Volume2} label="Listen" onClick={() => speak(result.text, targetLang, ttsRate)} />
        <IconBtn icon={Star} label="Save to favorites" onClick={onToggleFavorite} active={isFavorite} />
      </div>
    </Card>
  );
};

/* --------------------------------------------------------------------------
   HOME
-------------------------------------------------------------------------- */

const Logo = ({ size = 40 }) => (
  <div
    style={{
      width: size, height: size, borderRadius: size * 0.32, background: C.neon,
      display: "flex", alignItems: "center", justifyContent: "center",
      boxShadow: `0 0 22px -2px ${C.neonGlow}`, flexShrink: 0,
    }}
  >
    <span className="zed-display" style={{ fontWeight: 700, fontSize: size * 0.46, color: "#06120C" }}>Z</span>
  </div>
);

const HomeScreen = ({ go, history, quickFrom, quickTo, setQuickFrom, setQuickTo, openSheet }) => {
  const recent = history.slice(0, 3);
  return (
    <div className="zed-fade-in" style={{ padding: "20px 20px 12px" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 22 }}>
        <Logo />
        <div>
          <div className="zed-display" style={{ fontSize: 20, fontWeight: 700, color: C.text, lineHeight: 1.1 }}>ZED AI</div>
          <div style={{ fontSize: 12.5, color: C.textDim }}>Smart Translator</div>
        </div>
        <div style={{ marginLeft: "auto" }}><DemoBadge /></div>
      </div>

      <button
        onClick={() => go("translate")}
        className="zed-focus"
        style={{
          width: "100%", textAlign: "left", display: "flex", alignItems: "center", gap: 10,
          background: C.surface, border: `1px solid ${C.borderSoft}`, borderRadius: 18,
          padding: "16px 16px", marginBottom: 16, cursor: "pointer",
        }}
      >
        <Search size={18} color={C.textFaint} />
        <span style={{ color: C.textFaint, fontSize: 14.5 }}>What do you want to translate?</span>
      </button>

      <div style={{ display: "flex", gap: 10, marginBottom: 22 }}>
        <LangChip code={quickFrom} onClick={() => openSheet("quickFrom")} />
        <button
          onClick={() => { setQuickFrom(quickTo); setQuickTo(quickFrom); }}
          className="zed-focus"
          aria-label="Swap languages"
          style={{ width: 40, height: 40, borderRadius: 12, background: C.surface2, border: `1px solid ${C.borderSoft}`, color: C.neon, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", flexShrink: 0 }}
        >
          <ArrowLeftRight size={16} />
        </button>
        <LangChip code={quickTo} onClick={() => openSheet("quickTo")} />
      </div>

      <div style={{ fontSize: 13, fontWeight: 600, color: C.textDim, marginBottom: 10 }}>Quick tools</div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 24 }}>
        <QuickCard icon={Mic} title="Voice" sub="Speak to translate" onClick={() => go("translate", { voice: true })} />
        <QuickCard icon={CameraIcon} title="Camera" sub="Translate text you see" onClick={() => go("camera")} />
        <QuickCard icon={Users} title="Conversation" sub="Two-way live chat" onClick={() => go("conversation")} />
        <QuickCard icon={Star} title="Favorites" sub="Saved translations" onClick={() => go("favorites")} />
      </div>

      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: C.textDim }}>Recent</div>
        {history.length > 0 && (
          <button onClick={() => go("history")} className="zed-focus" style={{ background: "none", border: "none", color: C.neon, fontSize: 12.5, fontWeight: 600, cursor: "pointer", display: "flex", alignItems: "center", gap: 2 }}>
            See all <ChevronRight size={13} />
          </button>
        )}
      </div>
      {recent.length === 0 ? (
        <Card style={{ textAlign: "center", color: C.textFaint, fontSize: 13 }}>
          Your recent translations will show up here.
        </Card>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {recent.map((h) => <HistoryRow key={h.id} item={h} compact />)}
        </div>
      )}
    </div>
  );
};

const QuickCard = ({ icon: Icon, title, sub, onClick }) => (
  <button
    onClick={onClick}
    className="zed-focus"
    style={{
      background: C.surface, border: `1px solid ${C.borderSoft}`, borderRadius: 18,
      padding: 15, textAlign: "left", cursor: "pointer", display: "flex", flexDirection: "column", gap: 20,
    }}
  >
    <div style={{ width: 34, height: 34, borderRadius: 10, background: C.neonDim, border: `1px solid ${C.neonBorder}`, display: "flex", alignItems: "center", justifyContent: "center" }}>
      <Icon size={16} color={C.neon} />
    </div>
    <div>
      <div style={{ color: C.text, fontWeight: 600, fontSize: 14 }}>{title}</div>
      <div style={{ color: C.textFaint, fontSize: 11.5, marginTop: 1 }}>{sub}</div>
    </div>
  </button>
);

/* --------------------------------------------------------------------------
   TRANSLATE (text + voice)
-------------------------------------------------------------------------- */

const MAX_CHARS = 2000;

const TranslateScreen = ({
  from, to, setFrom, setTo, openSheet, style, setStyle,
  text, setText, result, setResult, loading, setLoading,
  onTranslated, favorites, toggleFavorite, ttsRate, autoVoice,
}) => {
  const voice = useVoiceInput(from === "auto" ? "en" : from);
  const [showVoicePanel, setShowVoicePanel] = useState(!!autoVoice);
  const taRef = useRef(null);

  useEffect(() => { if (autoVoice) setShowVoicePanel(true); }, [autoVoice]);

  const runTranslate = useCallback(async (overrideText) => {
    const t = (overrideText ?? text).trim();
    if (!t) return;
    setLoading(true);
    setResult(null);
    const res = await translateWithAI({ text: t, sourceLang: from, targetLang: to, style });
    setLoading(false);
    setResult(res);
    onTranslated(t, res);
  }, [text, from, to, style, setLoading, setResult, onTranslated]);

  const swap = () => {
    if (from === "auto") return;
    setFrom(to); setTo(from);
    setText(result ? result.text : text);
    setResult(null);
  };

  const isFav = result && favorites.some((f) => f.sourceText === text && f.translatedText === result.text);

  const startVoice = () => {
    voice.start((transcript, isDemo) => {
      setText(transcript);
      runTranslate(transcript);
    });
  };

  return (
    <div className="zed-fade-in" style={{ padding: "18px 20px 12px" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
        <div>
          <div className="zed-display" style={{ fontSize: 21, fontWeight: 600, color: C.text }}>Translate</div>
          <div style={{ fontSize: 12.5, color: C.textDim, marginTop: 1 }}>AI-powered, context aware</div>
        </div>
        <DemoBadge />
      </div>

      <div className="zed-scroll" style={{ display: "flex", gap: 8, overflowX: "auto", marginBottom: 16, paddingBottom: 2 }}>
        {STYLES.map((s) => (
          <Pill key={s.id} active={style === s.id} onClick={() => setStyle(s.id)}>{s.label}</Pill>
        ))}
      </div>

      <div style={{ display: "flex", gap: 8, marginBottom: 14 }}>
        <LangChip code={from} onClick={() => openSheet("from")} />
        <button onClick={swap} className="zed-focus" aria-label="Swap languages" style={{ width: 40, height: 40, borderRadius: 12, background: C.surface2, border: `1px solid ${C.borderSoft}`, color: C.neon, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", flexShrink: 0 }}>
          <ArrowLeftRight size={16} />
        </button>
        <LangChip code={to} onClick={() => openSheet("to")} />
      </div>

      {showVoicePanel ? (
        <Card style={{ marginBottom: 14, textAlign: "center", paddingTop: 26, paddingBottom: 22 }}>
          <button onClick={() => setShowVoicePanel(false)} className="zed-focus" style={{ position: "relative", left: "calc(50% - 4px)", marginBottom: -8, background: "none", border: "none", color: C.textFaint, cursor: "pointer", fontSize: 12 }}>keyboard instead</button>
          <div style={{ display: "flex", justifyContent: "center", margin: "14px 0 12px" }}>
            <button onClick={startVoice} className="zed-focus" aria-label="Start voice input" style={{ background: "none", border: "none", cursor: "pointer", padding: 0 }}>
              <MicPulse />
            </button>
          </div>
          <div style={{ color: C.text, fontSize: 14, fontWeight: 500, minHeight: 20 }}>
            {voice.listening ? "Listening…" : text ? text : "Tap the mic and speak"}
          </div>
          {voice.listening && voice.demo && (
            <div style={{ color: C.textFaint, fontSize: 11.5, marginTop: 6 }}>Demo transcript — live speech recognition isn't available in this browser</div>
          )}
        </Card>
      ) : (
        <Card style={{ marginBottom: 14 }}>
          <textarea
            ref={taRef}
            value={text}
            onChange={(e) => setText(e.target.value.slice(0, MAX_CHARS))}
            placeholder="Enter text to translate…"
            rows={5}
            className="zed-focus"
            style={{ width: "100%", resize: "none", background: "none", border: "none", color: C.text, fontSize: 15.5, lineHeight: 1.5 }}
          />
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: 8, paddingTop: 10, borderTop: `1px solid ${C.borderSoft}` }}>
            <div style={{ display: "flex", gap: 8 }}>
              <IconBtn icon={Mic} label="Voice input" onClick={() => setShowVoicePanel(true)} size={16} />
              <IconBtn icon={X} label="Clear text" onClick={() => { setText(""); setResult(null); }} size={16} />
            </div>
            <div style={{ fontSize: 11.5, color: text.length > MAX_CHARS - 50 ? C.danger : C.textFaint }}>{text.length}/{MAX_CHARS}</div>
          </div>
        </Card>
      )}

      <GlowButton onClick={() => runTranslate()} loading={loading} disabled={!text.trim()} icon={Sparkles} style={{ marginBottom: 14 }}>
        {loading ? "Translating" : "Translate"}
      </GlowButton>

      {loading && <ScanLoader />}

      <ResultCard
        sourceText={text}
        result={result}
        targetLang={to}
        isFavorite={isFav}
        ttsRate={ttsRate}
        onToggleFavorite={() => toggleFavorite({ sourceText: text, translatedText: result.text, sourceLang: from, targetLang: to, style })}
      />
    </div>
  );
};

/* --------------------------------------------------------------------------
   CAMERA
-------------------------------------------------------------------------- */

const CameraScreen = ({ to, openSheet, onTranslated, favorites, toggleFavorite, ttsRate }) => {
  const [phase, setPhase] = useState("idle"); // idle | scanning | ocr | done
  const [detected, setDetected] = useState("");
  const [result, setResult] = useState(null);

  const capture = async () => {
    setPhase("scanning");
    setResult(null);
    setTimeout(async () => {
      setPhase("ocr");
      const text = await runOcrOnCapture();
      setDetected(text);
      const res = await translateWithAI({ text, sourceLang: "auto", targetLang: to, style: "standard" });
      setResult(res);
      onTranslated(text, res);
      setPhase("done");
    }, 500);
  };

  const reset = () => { setPhase("idle"); setDetected(""); setResult(null); };
  const isFav = result && favorites.some((f) => f.sourceText === detected && f.translatedText === result.text);

  return (
    <div className="zed-fade-in" style={{ padding: "18px 20px 12px" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
        <div>
          <div className="zed-display" style={{ fontSize: 21, fontWeight: 600, color: C.text }}>Camera</div>
          <div style={{ fontSize: 12.5, color: C.textDim, marginTop: 1 }}>Point, capture, translate</div>
        </div>
        <DemoBadge />
      </div>

      <div style={{ display: "flex", gap: 8, marginBottom: 14 }}>
        <div style={{ flex: 1 }} />
        <LangChip code={to} onClick={() => openSheet("to")} />
      </div>

      <div
        style={{
          position: "relative", width: "100%", aspectRatio: "3/4", borderRadius: 22, overflow: "hidden",
          background: "linear-gradient(160deg, #17181A, #0B0C0D)", border: `1px solid ${C.borderSoft}`, marginBottom: 16,
        }}
      >
        {["idle", "scanning", "ocr"].includes(phase) && (
          <>
            <Corner style={{ top: 18, left: 18, borderRight: "none", borderBottom: "none" }} />
            <Corner style={{ top: 18, right: 18, borderLeft: "none", borderBottom: "none" }} />
            <Corner style={{ bottom: 18, left: 18, borderRight: "none", borderTop: "none" }} />
            <Corner style={{ bottom: 18, right: 18, borderLeft: "none", borderTop: "none" }} />
          </>
        )}
        {(phase === "scanning" || phase === "ocr") && (
          <div style={{ position: "absolute", left: "8%", right: "8%", height: 2, background: C.neon, boxShadow: `0 0 14px 2px ${C.neonGlow}`, animation: "zedScan 1.3s ease-in-out infinite" }} />
        )}
        <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column", gap: 10, textAlign: "center", padding: 24 }}>
          {phase === "idle" && (
            <>
              <ScanLine size={30} color={C.textFaint} />
              <div style={{ color: C.textFaint, fontSize: 13 }}>Frame text and tap capture.<br />Live camera preview is simulated in this demo.</div>
            </>
          )}
          {phase === "scanning" && <div style={{ color: C.textDim, fontSize: 13.5 }}>Capturing…</div>}
          {phase === "ocr" && (
            <>
              <Loader2 size={22} color={C.neon} style={{ animation: "zedSpin .8s linear infinite" }} />
              <div style={{ color: C.textDim, fontSize: 13.5 }}>Reading text…</div>
            </>
          )}
          {phase === "done" && (
            <div style={{ background: "rgba(0,0,0,0.35)", borderRadius: 14, padding: 14, textAlign: "left" }}>
              <div style={{ color: C.textFaint, fontSize: 11, fontWeight: 600, marginBottom: 4 }}>DETECTED TEXT</div>
              <div style={{ color: C.text, fontSize: 14, lineHeight: 1.4 }}>{detected}</div>
            </div>
          )}
        </div>
      </div>

      {phase !== "done" ? (
        <GlowButton onClick={capture} loading={phase === "scanning" || phase === "ocr"} icon={CameraIcon}>
          Capture
        </GlowButton>
      ) : (
        <div style={{ display: "flex", gap: 10 }}>
          <button onClick={reset} className="zed-focus" style={{ flex: 1, padding: "14px", borderRadius: 16, background: C.surface2, border: `1px solid ${C.borderSoft}`, color: C.text, fontWeight: 600, fontSize: 14.5, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}>
            <RotateCcw size={16} /> Retake
          </button>
        </div>
      )}

      {phase === "done" && (
        <div style={{ marginTop: 14 }}>
          <ResultCard
            sourceText={detected}
            result={result}
            targetLang={to}
            isFavorite={isFav}
            ttsRate={ttsRate}
            onToggleFavorite={() => toggleFavorite({ sourceText: detected, translatedText: result.text, sourceLang: "auto", targetLang: to, style: "standard" })}
          />
        </div>
      )}
    </div>
  );
};

const Corner = ({ style }) => (
  <div style={{ position: "absolute", width: 26, height: 26, border: `2px solid ${C.neon}`, borderRadius: 6, opacity: 0.85, ...style }} />
);

/* --------------------------------------------------------------------------
   CONVERSATION MODE
-------------------------------------------------------------------------- */

const ConversationScreen = ({ openSheet, langA, langB, onTranslated, ttsRate }) => {
  const [messages, setMessages] = useState([]);
  const [busy, setBusy] = useState(null); // 'A' | 'B' | null
  const voiceA = useVoiceInput(langA);
  const voiceB = useVoiceInput(langB);
  const endRef = useRef(null);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages, busy]);

  const speakTurn = async (speaker, text) => {
    const source = speaker === "A" ? langA : langB;
    const target = speaker === "A" ? langB : langA;
    setBusy(speaker);
    const res = await translateWithAI({ text, sourceLang: source, targetLang: target, style: "standard" });
    const msg = { id: uid(), speaker, original: text, translated: res.text, demo: res.demo, sourceLang: source, targetLang: target };
    setMessages((m) => [...m, msg]);
    onTranslated(text, res);
    setBusy(null);
    speak(res.text, target, ttsRate);
  };

  const mic = (speaker) => {
    const v = speaker === "A" ? voiceA : voiceB;
    v.start((transcript) => speakTurn(speaker, transcript));
  };

  return (
    <div className="zed-fade-in" style={{ padding: "18px 20px 0", display: "flex", flexDirection: "column", height: "100%" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 14 }}>
        <div>
          <div className="zed-display" style={{ fontSize: 21, fontWeight: 600, color: C.text }}>Conversation</div>
          <div style={{ fontSize: 12.5, color: C.textDim, marginTop: 1 }}>Two people, two languages</div>
        </div>
        <DemoBadge />
      </div>

      <div style={{ display: "flex", gap: 10, marginBottom: 14 }}>
        <PersonPill label="Person A" code={langA} onClick={() => openSheet("convA")} />
        <PersonPill label="Person B" code={langB} onClick={() => openSheet("convB")} />
      </div>

      <div className="zed-scroll" style={{ flex: 1, overflowY: "auto", display: "flex", flexDirection: "column", gap: 10, paddingBottom: 12, minHeight: 180 }}>
        {messages.length === 0 && !busy && (
          <div style={{ textAlign: "center", color: C.textFaint, fontSize: 13, padding: "30px 10px" }}>
            Tap a mic below to start. Each turn is translated and read aloud automatically.
          </div>
        )}
        {messages.map((m) => (
          <div key={m.id} style={{ display: "flex", justifyContent: m.speaker === "A" ? "flex-start" : "flex-end" }}>
            <div style={{ maxWidth: "80%", background: m.speaker === "A" ? C.surface : C.neonDim, border: `1px solid ${m.speaker === "A" ? C.borderSoft : C.neonBorder}`, borderRadius: 16, padding: 12 }}>
              <div style={{ color: C.textFaint, fontSize: 10.5, fontWeight: 600, marginBottom: 3 }}>{m.speaker === "A" ? "PERSON A" : "PERSON B"} · {langByCode(m.sourceLang).name}</div>
              <div style={{ color: C.textDim, fontSize: 12.5, marginBottom: 4 }}>{m.original}</div>
              <div style={{ color: C.text, fontSize: 14.5, fontWeight: 500 }}>{m.translated}</div>
              {m.demo && <div style={{ color: C.textFaint, fontSize: 10.5, marginTop: 4 }}>demo output</div>}
            </div>
          </div>
        ))}
        {busy && (
          <div style={{ display: "flex", justifyContent: busy === "A" ? "flex-start" : "flex-end" }}>
            <div style={{ padding: "10px 14px" }}><ScanLoader label="Translating" /></div>
          </div>
        )}
        <div ref={endRef} />
      </div>

      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 4px 20px" }}>
        <MicRow label="A" code={langA} listening={voiceA.listening} onPress={() => mic("A")} />
        <MicRow label="B" code={langB} listening={voiceB.listening} onPress={() => mic("B")} align="right" />
      </div>
    </div>
  );
};

const PersonPill = ({ label, code, onClick }) => {
  const l = langByCode(code);
  return (
    <button onClick={onClick} className="zed-focus" style={{ flex: 1, background: C.surface, border: `1px solid ${C.borderSoft}`, borderRadius: 14, padding: "10px 12px", textAlign: "left", cursor: "pointer" }}>
      <div style={{ color: C.textFaint, fontSize: 10.5, fontWeight: 600, marginBottom: 2 }}>{label.toUpperCase()}</div>
      <div style={{ color: C.text, fontSize: 13.5, fontWeight: 500, display: "flex", alignItems: "center", gap: 5 }}>{l.flag} {l.name}</div>
    </button>
  );
};

const MicRow = ({ code, listening, onPress }) => (
  <button onClick={onPress} className="zed-focus" style={{ background: "none", border: "none", cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
    <div style={{ width: 54, height: 54, borderRadius: "50%", background: listening ? C.neon : C.surface2, border: `1px solid ${listening ? C.neon : C.borderSoft}`, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: listening ? `0 0 18px 2px ${C.neonGlow}` : "none" }}>
      <Mic size={22} color={listening ? "#06120C" : C.textDim} />
    </div>
    <span style={{ fontSize: 11, color: C.textFaint }}>{langByCode(code).name}</span>
  </button>
);

/* --------------------------------------------------------------------------
   HISTORY + FAVORITES
-------------------------------------------------------------------------- */

const HistoryRow = ({ item, compact, onCopy, onDelete, onToggleFav }) => {
  const s = langByCode(item.sourceLang);
  const t = langByCode(item.targetLang);
  return (
    <Card style={{ padding: 13 }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 7 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 5, color: C.textFaint, fontSize: 11.5 }}>
          <span>{s.flag}</span><span>{s.name}</span>
          <ArrowLeftRight size={10} />
          <span>{t.flag}</span><span>{t.name}</span>
        </div>
        {!compact && (
          <div style={{ display: "flex", gap: 6 }}>
            <IconBtn icon={Star} label="Favorite" size={13} onClick={() => onToggleFav?.(item)} active={item.favorite} />
            <IconBtn icon={Copy} label="Copy" size={13} onClick={() => onCopy?.(item)} />
            <IconBtn icon={Trash2} label="Delete" size={13} onClick={() => onDelete?.(item)} danger />
          </div>
        )}
      </div>
      <div style={{ color: C.textDim, fontSize: 12.5, marginBottom: 3, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{item.sourceText}</div>
      <div style={{ color: C.text, fontSize: 14.5, fontWeight: 500, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{item.translatedText}</div>
    </Card>
  );
};

const HistoryScreen = ({ history, onDelete, onToggleFav, onClearAll, go, favoritesOnly }) => {
  const [q, setQ] = useState("");
  const source = favoritesOnly ? history.filter((h) => h.favorite) : history;
  const filtered = source.filter(
    (h) => h.sourceText.toLowerCase().includes(q.toLowerCase()) || h.translatedText.toLowerCase().includes(q.toLowerCase())
  );

  const copy = async (item) => { try { await navigator.clipboard.writeText(item.translatedText); } catch (e) {} };

  return (
    <div className="zed-fade-in" style={{ padding: "18px 20px 12px" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
        <div className="zed-display" style={{ fontSize: 21, fontWeight: 600, color: C.text }}>{favoritesOnly ? "Favorites" : "History"}</div>
        <div style={{ display: "flex", gap: 8 }}>
          {!favoritesOnly && (
            <IconBtn icon={Star} label="Favorites" onClick={() => go("favorites")} />
          )}
          {!favoritesOnly && history.length > 0 && (
            <IconBtn icon={Trash2} label="Clear history" onClick={onClearAll} danger />
          )}
        </div>
      </div>

      {!favoritesOnly && (
        <div style={{ display: "flex", alignItems: "center", gap: 8, background: C.surface2, border: `1px solid ${C.borderSoft}`, borderRadius: 14, padding: "10px 13px", marginBottom: 16 }}>
          <Search size={16} color={C.textFaint} />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search history"
            className="zed-focus"
            style={{ background: "none", border: "none", color: C.text, fontSize: 14, width: "100%" }}
          />
        </div>
      )}

      {filtered.length === 0 ? (
        <EmptyState
          icon={favoritesOnly ? Star : HistoryIcon}
          title={favoritesOnly ? "No favorites yet" : "No translations yet"}
          sub={favoritesOnly ? "Tap the star on any translation to save it here." : "Translations you make will appear here automatically."}
        />
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 9 }}>
          {filtered.map((h) => (
            <HistoryRow key={h.id} item={h} onCopy={copy} onDelete={onDelete} onToggleFav={onToggleFav} />
          ))}
        </div>
      )}
    </div>
  );
};

/* --------------------------------------------------------------------------
   SETTINGS
-------------------------------------------------------------------------- */

const SettingsSection = ({ title, children }) => (
  <div style={{ marginBottom: 22 }}>
    <div style={{ fontSize: 12.5, fontWeight: 600, color: C.textDim, marginBottom: 9, paddingLeft: 4 }}>{title}</div>
    <Card style={{ padding: 4 }}>{children}</Card>
  </div>
);

const SettingsRow = ({ icon: Icon, label, sub, right, onClick, last }) => (
  <button
    onClick={onClick}
    className="zed-focus"
    style={{
      width: "100%", display: "flex", alignItems: "center", gap: 12, padding: "12px 10px",
      background: "none", border: "none", borderBottom: last ? "none" : `1px solid ${C.borderSoft}`,
      cursor: onClick ? "pointer" : "default", textAlign: "left",
    }}
  >
    <div style={{ width: 32, height: 32, borderRadius: 9, background: C.surface2, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
      <Icon size={15} color={C.textDim} />
    </div>
    <div style={{ flex: 1, minWidth: 0 }}>
      <div style={{ color: C.text, fontSize: 14, fontWeight: 500 }}>{label}</div>
      {sub && <div style={{ color: C.textFaint, fontSize: 11.5, marginTop: 1 }}>{sub}</div>}
    </div>
    {right}
  </button>
);

const Toggle = ({ on, onClick }) => (
  <button
    onClick={onClick}
    aria-pressed={on}
    className="zed-focus"
    style={{ width: 42, height: 25, borderRadius: 999, background: on ? C.neon : C.surface3, border: `1px solid ${on ? C.neon : C.borderSoft}`, position: "relative", cursor: "pointer", flexShrink: 0 }}
  >
    <div style={{ position: "absolute", top: 2, left: on ? 19 : 2, width: 19, height: 19, borderRadius: "50%", background: on ? "#06120C" : C.textDim, transition: "left .15s ease" }} />
  </button>
);

const SettingsScreen = ({ settings, setSettings, onClearHistory, historyCount }) => {
  const upd = (patch) => setSettings((s) => ({ ...s, ...patch }));
  return (
    <div className="zed-fade-in" style={{ padding: "18px 20px 12px" }}>
      <div className="zed-display" style={{ fontSize: 21, fontWeight: 600, color: C.text, marginBottom: 18 }}>Settings</div>

      <SettingsSection title="Translation preferences">
        <SettingsRow icon={Sparkles} label="Default style" sub={STYLES.find(s => s.id === settings.defaultStyle)?.label}
          right={
            <select
              value={settings.defaultStyle}
              onChange={(e) => upd({ defaultStyle: e.target.value })}
              className="zed-focus"
              style={{ background: C.surface2, color: C.text, border: `1px solid ${C.borderSoft}`, borderRadius: 9, fontSize: 12.5, padding: "5px 7px" }}
            >
              {STYLES.map((s) => <option key={s.id} value={s.id}>{s.label}</option>)}
            </select>
          }
        />
        <SettingsRow icon={BookOpen} label="Auto-detect source language" sub="Skip picking a source language"
          right={<Toggle on={settings.autoDetect} onClick={() => upd({ autoDetect: !settings.autoDetect })} />} last
        />
      </SettingsSection>

      <SettingsSection title="Text-to-speech">
        <SettingsRow icon={Volume2} label="Auto-read translations" sub="Play audio as soon as a result appears"
          right={<Toggle on={settings.autoRead} onClick={() => upd({ autoRead: !settings.autoRead })} />}
        />
        <SettingsRow icon={SlidersHorizontal} label="Speech rate" sub={`${settings.ttsRate.toFixed(1)}×`}
          right={
            <input type="range" min="0.5" max="1.5" step="0.1" value={settings.ttsRate}
              onChange={(e) => upd({ ttsRate: parseFloat(e.target.value) })}
              className="zed-focus" style={{ width: 90, accentColor: C.neon }} />
          } last
        />
      </SettingsSection>

      <SettingsSection title="Appearance">
        <SettingsRow icon={ShieldCheck} label="Theme" sub="Dark (premium) — the only theme ZED AI ships with" last
          right={<span style={{ color: C.neon, fontSize: 12, fontWeight: 600 }}>Dark</span>} />
      </SettingsSection>

      <SettingsSection title="Data">
        <SettingsRow icon={Trash2} label="Clear history" sub={`${historyCount} saved translation${historyCount === 1 ? "" : "s"}`} onClick={onClearHistory} last />
      </SettingsSection>

      <SettingsSection title="Privacy">
        <SettingsRow icon={ShieldCheck} label="Your text stays on this device" sub="History and favorites are stored privately for your account only" last />
      </SettingsSection>

      <SettingsSection title="About ZED AI">
        <SettingsRow icon={Info} label="Version" sub="1.0.0 — demo build" last={false} />
        <div style={{ padding: "10px 10px 14px", color: C.textDim, fontSize: 12.5, lineHeight: 1.6 }}>
          ZED AI is currently running in demo mode: it has no live AI translation, speech, or OCR backend connected. Text-to-speech works for real, using your browser's built-in voice engine. To go live, add a server route that calls a translation/AI provider with a securely stored API key, then point <code style={{ color: C.neon }}>translateWithAI()</code> at it instead of the built-in sample dictionary.
        </div>
      </SettingsSection>
    </div>
  );
};

/* --------------------------------------------------------------------------
   BOTTOM NAVIGATION
-------------------------------------------------------------------------- */

const NAV = [
  { id: "home", label: "Home", icon: HomeIcon },
  { id: "translate", label: "Translate", icon: Sparkles },
  { id: "camera", label: "Camera", icon: CameraIcon },
  { id: "history", label: "History", icon: HistoryIcon },
  { id: "settings", label: "Settings", icon: SettingsIcon },
];

const BottomNav = ({ view, go }) => (
  <div style={{ display: "flex", borderTop: `1px solid ${C.borderSoft}`, background: C.bgSoft, padding: "8px 6px calc(env(safe-area-inset-bottom,0px) + 8px)", flexShrink: 0 }}>
    {NAV.map((n) => {
      const active = view === n.id || (n.id === "history" && view === "favorites");
      const Icon = n.icon;
      return (
        <button
          key={n.id}
          onClick={() => go(n.id)}
          className="zed-focus"
          style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 3, padding: "6px 2px", background: "none", border: "none", cursor: "pointer" }}
        >
          <Icon size={20} color={active ? C.neon : C.textFaint} strokeWidth={active ? 2.4 : 2} style={active ? { filter: `drop-shadow(0 0 6px ${C.neonGlow})` } : undefined} />
          <span style={{ fontSize: 10.5, fontWeight: active ? 600 : 500, color: active ? C.neon : C.textFaint }}>{n.label}</span>
        </button>
      );
    })}
  </div>
);

/* --------------------------------------------------------------------------
   APP ROOT
-------------------------------------------------------------------------- */

export default function App() {
  const [view, setView] = useState("home");
  const [navParams, setNavParams] = useState({});
  const [sheet, setSheet] = useState(null); // which language picker is open

  const [history, setHistory] = useState([]);
  const [settings, setSettings] = useState({ defaultStyle: "standard", autoDetect: false, autoRead: false, ttsRate: 1 });
  const [ready, setReady] = useState(false);

  // Translate screen state
  const [from, setFrom] = useState("auto");
  const [to, setTo] = useState("uz");
  const [style, setStyle] = useState("standard");
  const [text, setText] = useState("");
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  // Home quick-pick state
  const [quickFrom, setQuickFrom] = useState("en");
  const [quickTo, setQuickTo] = useState("es");

  // Conversation state
  const [langA, setLangA] = useState("en");
  const [langB, setLangB] = useState("ja");

  useEffect(() => {
    (async () => {
      const h = await storageGet("zed-history", []);
      const s = await storageGet("zed-settings", null);
      setHistory(h);
      if (s) setSettings((prev) => ({ ...prev, ...s }));
      setReady(true);
    })();
  }, []);

  useEffect(() => { if (ready) storageSet("zed-history", history); }, [history, ready]);
  useEffect(() => { if (ready) storageSet("zed-settings", settings); }, [settings, ready]);
  useEffect(() => { setStyle(settings.defaultStyle); }, [settings.defaultStyle]);
  useEffect(() => { if (settings.autoDetect) setFrom("auto"); }, [settings.autoDetect]);

  const go = (v, params) => { setView(v); setNavParams(params || {}); };

  const recordTranslation = useCallback((sourceText, res) => {
    if (!sourceText?.trim()) return;
    setHistory((h) => [{ id: uid(), sourceText, translatedText: res.text, sourceLang: from, targetLang: to, style, favorite: false, ts: Date.now() }, ...h].slice(0, 200));
  }, [from, to, style]);

  const toggleFavoriteFromResult = useCallback((entry) => {
    setHistory((h) => {
      const idx = h.findIndex((x) => x.sourceText === entry.sourceText && x.translatedText === entry.translatedText);
      if (idx === -1) {
        return [{ id: uid(), ...entry, favorite: true, ts: Date.now() }, ...h];
      }
      const copy = [...h];
      copy[idx] = { ...copy[idx], favorite: !copy[idx].favorite };
      return copy;
    });
  }, []);

  const toggleFavRow = (item) => setHistory((h) => h.map((x) => x.id === item.id ? { ...x, favorite: !x.favorite } : x));
  const deleteRow = (item) => setHistory((h) => h.filter((x) => x.id !== item.id));
  const clearHistory = () => { if (history.length && window.confirm("Clear all translation history? Favorites will be removed too.")) setHistory([]); };

  const openSheet = (which) => setSheet(which);
  const closeSheet = () => setSheet(null);
  const pickLang = (code) => {
    if (sheet === "from") setFrom(code);
    else if (sheet === "to") setTo(code);
    else if (sheet === "quickFrom") setQuickFrom(code);
    else if (sheet === "quickTo") setQuickTo(code);
    else if (sheet === "convA") setLangA(code);
    else if (sheet === "convB") setLangB(code);
  };
  const sheetCurrent = { from, to, quickFrom, quickTo, convA: langA, convB: langB }[sheet] || "";

  const favList = history.filter((h) => h.favorite);

  return (
    <div className="zed-root" style={{ width: "100%", height: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "#000" }}>
      <FontLoader />
      <div
        style={{
          width: "100%", maxWidth: 430, height: "100%", maxHeight: 932, background: C.bg,
          display: "flex", flexDirection: "column", position: "relative", overflow: "hidden",
          boxShadow: "0 0 60px rgba(0,0,0,0.6)", border: `1px solid ${C.borderSoft}`,
        }}
      >
        <div className="zed-scroll" style={{ flex: 1, overflowY: "auto", display: "flex", flexDirection: "column" }}>
          {view === "home" && (
            <HomeScreen go={go} history={history} quickFrom={quickFrom} quickTo={quickTo} setQuickFrom={setQuickFrom} setQuickTo={setQuickTo} openSheet={openSheet} />
          )}
          {view === "translate" && (
            <TranslateScreen
              from={from} to={to} setFrom={setFrom} setTo={setTo} openSheet={openSheet}
              style={style} setStyle={setStyle} text={text} setText={setText}
              result={result} setResult={setResult} loading={loading} setLoading={setLoading}
              onTranslated={recordTranslation} favorites={history}
              toggleFavorite={toggleFavoriteFromResult} ttsRate={settings.ttsRate} autoVoice={navParams.voice}
            />
          )}
          {view === "camera" && (
            <CameraScreen to={to} openSheet={openSheet} onTranslated={recordTranslation} favorites={history} toggleFavorite={toggleFavoriteFromResult} ttsRate={settings.ttsRate} />
          )}
          {view === "conversation" && (
            <ConversationScreen openSheet={openSheet} langA={langA} langB={langB} onTranslated={recordTranslation} ttsRate={settings.ttsRate} />
          )}
          {view === "history" && (
            <HistoryScreen history={history} onDelete={deleteRow} onToggleFav={toggleFavRow} onClearAll={clearHistory} go={go} />
          )}
          {view === "favorites" && (
            <HistoryScreen history={history} onDelete={deleteRow} onToggleFav={toggleFavRow} go={go} favoritesOnly />
          )}
          {view === "settings" && (
            <SettingsScreen settings={settings} setSettings={setSettings} onClearHistory={clearHistory} historyCount={history.length} />
          )}
          <div style={{ height: 6 }} />
        </div>

        <BottomNav view={view} go={go} />

        <LanguageSheet
          open={!!sheet}
          onClose={closeSheet}
          onPick={pickLang}
          current={sheetCurrent}
          excludeAuto={sheet === "quickFrom" || sheet === "quickTo" || sheet === "convA" || sheet === "convB"}
        />
      </div>
    </div>
  );
}
